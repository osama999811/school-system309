# school-system-online

## التشغيل المحلي
```bash
npm install
npm run dev
```

## النشر المجاني على Cloudflare Pages
1. ارفع المشروع إلى GitHub.
2. افتح Cloudflare Pages.
3. اربط المستودع.
4. Build command: `npm run build`
5. Output directory: `dist`

## إيقاف وتشغيل الموقع
افتح `src/siteConfig.js`:
- `SITE_OPEN = true` لتشغيل الموقع
- `SITE_OPEN = false` لإظهار صفحة الصيانة

ثم ارفع التعديل إلى GitHub وسيُعاد النشر تلقائيًا.
