// غيّرها إلى false لإيقاف الموقع ووضعه على صفحة صيانة
export const SITE_OPEN = true;
