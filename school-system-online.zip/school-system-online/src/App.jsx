import { useEffect, useMemo, useRef, useState } from 'react'
import { SITE_OPEN } from './siteConfig'

const storage = {
  get(key, fallback) {
    try {
      const raw = localStorage.getItem(key)
      return raw ? JSON.parse(raw) : fallback
    } catch {
      return fallback
    }
  },
  set(key, value) {
    try { localStorage.setItem(key, JSON.stringify(value)) } catch {}
  },
}

const defaultTeachers = [
  { id: 'TCH001', name: 'أ. محمود علي', subject: 'رياضيات', classes: 4 },
  { id: 'TCH002', name: 'أ. سارة محمد', subject: 'علوم', classes: 3 },
]

const defaultStudents = [
  { id: 'STD001', name: 'محمد أحمد', grade: 'الصف الأول', attendance: 95, gpa: 89, teacherId: 'TCH001', fees: 5000, feesPaid: 3000, level: 'جيد' },
  { id: 'STD002', name: 'فاطمة علي', grade: 'الصف الثاني', attendance: 98, gpa: 94, teacherId: 'TCH001', fees: 5000, feesPaid: 5000, level: 'ممتاز' },
]

const codes = {
  ADM001: { role: 'admin', name: 'مدير النظام', id: 'ADM001' },
  TCH001: { role: 'teacher', name: 'أ. محمود علي', id: 'TCH001' },
  TCH002: { role: 'teacher', name: 'أ. سارة محمد', id: 'TCH002' },
  STD001: { role: 'student', name: 'محمد أحمد', id: 'STD001' },
  STD002: { role: 'student', name: 'فاطمة علي', id: 'STD002' },
}

const fmtDate = () => new Date().toLocaleDateString('ar-EG')
const fmtTime = () => new Date().toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' })
const uid = () => Math.random().toString(36).slice(2, 8).toUpperCase()

function Button({ children, variant = 'primary', ...props }) {
  return <button className={`btn ${variant === 'primary' ? 'btn-primary' : 'btn-soft'}`} {...props}>{children}</button>
}

function Stat({ label, value }) {
  return <div className="stat"><p className="k">{label}</p><h3 className="v">{value}</h3></div>
}

function Modal({ title, children, onClose }) {
  return (
    <div className="modal-bg" onMouseDown={onClose}>
      <div className="modal" onMouseDown={e => e.stopPropagation()}>
        <div className="section-head" style={{ marginBottom: 18 }}>
          <div>
            <h2 className="h1" style={{ fontSize: 20 }}>{title}</h2>
          </div>
          <Button variant="soft" onClick={onClose}>إغلاق</Button>
        </div>
        {children}
      </div>
    </div>
  )
}

function Field({ label, ...props }) {
  return <div style={{ marginBottom: 14 }}><label className="label">{label}</label><input className="input" {...props} /></div>
}

function SelectField({ label, children, ...props }) {
  return <div style={{ marginBottom: 14 }}><label className="label">{label}</label><select className="select" {...props}>{children}</select></div>
}

function TextareaField({ label, ...props }) {
  return <div style={{ marginBottom: 14 }}><label className="label">{label}</label><textarea className="textarea" {...props} /></div>
}

function Badge({ children, color = '#e2e8f0', text = '#334155' }) {
  return <span className="badge" style={{ background: color, color: text }}>{children}</span>
}

function Progress({ value, max }) {
  const pct = Math.max(0, Math.min(100, Math.round((value / (max || 1)) * 100)))
  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 6 }}>
        <span className="small">{value.toLocaleString()} / {max.toLocaleString()}</span>
        <span style={{ fontSize: 13, fontWeight: 800 }}>{pct}%</span>
      </div>
      <div style={{ height: 10, background: '#e2e8f0', borderRadius: 999, overflow: 'hidden' }}>
        <div style={{ width: `${pct}%`, height: '100%', background: '#173a5e' }} />
      </div>
    </div>
  )
}

function App() {
  const [page, setPage] = useState('login')
  const [user, setUser] = useState(null)
  const [tab, setTab] = useState('home')

  const [schoolName, setSchoolName] = useState(() => storage.get('schoolName', 'نظام الإدارة التعليمية'))
  const [schoolColor, setSchoolColor] = useState(() => storage.get('schoolColor', '#173a5e'))
  const [schoolLogo, setSchoolLogo] = useState(() => storage.get('schoolLogo', null))
  const [teachers, setTeachers] = useState(() => storage.get('teachers', defaultTeachers))
  const [students, setStudents] = useState(() => storage.get('students', defaultStudents))
  const [messages, setMessages] = useState(() => storage.get('messages', []))
  const [attendance, setAttendance] = useState(() => storage.get('attendance', []))
  const [ratings, setRatings] = useState(() => storage.get('ratings', []))

  useEffect(() => storage.set('schoolName', schoolName), [schoolName])
  useEffect(() => storage.set('schoolColor', schoolColor), [schoolColor])
  useEffect(() => storage.set('schoolLogo', schoolLogo), [schoolLogo])
  useEffect(() => storage.set('teachers', teachers), [teachers])
  useEffect(() => storage.set('students', students), [students])
  useEffect(() => storage.set('messages', messages), [messages])
  useEffect(() => storage.set('attendance', attendance), [attendance])
  useEffect(() => storage.set('ratings', ratings), [ratings])

  const login = (code) => {
    const u = codes[code.trim().toUpperCase()]
    if (!u) return false
    setUser(u)
    setPage('app')
    setTab('home')
    return true
  }

  const logout = () => {
    setUser(null)
    setPage('login')
  }

  const unreadCount = (id) => messages.filter(m => m.toId === id && !m.read).length

  if (!SITE_OPEN) return <Maintenance schoolName={schoolName} schoolLogo={schoolLogo} schoolColor={schoolColor} />

  return (
    <div style={{ minHeight: '100%', direction: 'rtl' }}>
      {page === 'login' ? (
        <LoginPage schoolName={schoolName} schoolLogo={schoolLogo} schoolColor={schoolColor} onLogin={login} />
      ) : (
        <AppShell
          user={user}
          tab={tab}
          setTab={setTab}
          logout={logout}
          schoolName={schoolName}
          schoolLogo={schoolLogo}
          schoolColor={schoolColor}
          teachers={teachers}
          setTeachers={setTeachers}
          students={students}
          setStudents={setStudents}
          messages={messages}
          setMessages={setMessages}
          attendance={attendance}
          setAttendance={setAttendance}
          ratings={ratings}
          setRatings={setRatings}
          unreadCount={unreadCount}
          setSchoolName={setSchoolName}
          setSchoolColor={setSchoolColor}
          setSchoolLogo={setSchoolLogo}
        />
      )}
    </div>
  )
}

function Maintenance({ schoolName, schoolLogo, schoolColor }) {
  return (
    <div style={{ minHeight: '100vh', display: 'grid', placeItems: 'center', padding: 20, background: 'linear-gradient(135deg,#eef3fa,#f8fbff)' }}>
      <div className="card" style={{ maxWidth: 420, width: '100%', textAlign: 'center' }}>
        <div style={{ width: 86, height: 86, borderRadius: 24, background: schoolColor, margin: '0 auto 16px', display: 'grid', placeItems: 'center', overflow: 'hidden', color: '#fff', fontSize: 36 }}>
          {schoolLogo ? <img src={schoolLogo} alt="logo" style={{ width: '100%', height: '100%', objectFit: 'cover' }} /> : '🏫'}
        </div>
        <h1 className="h1">{schoolName}</h1>
        <p className="sub" style={{ fontSize: 14, marginBottom: 0 }}>الموقع متوقف مؤقتًا للصيانة</p>
      </div>
    </div>
  )
}

function LoginPage({ schoolName, schoolLogo, schoolColor, onLogin }) {
  const [code, setCode] = useState('')
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)

  const submit = async () => {
    if (!code.trim()) {
      setError('يرجى إدخال كود الدخول')
      return
    }
    setLoading(true)
    await new Promise(r => setTimeout(r, 300))
    const ok = onLogin(code)
    if (!ok) setError('الكود غير صحيح')
    setLoading(false)
  }

  return (
    <div style={{ minHeight: '100vh', display: 'grid', placeItems: 'center', padding: 20, background: 'radial-gradient(circle at top, #dfeaf7, #f3f6fb 55%)' }}>
      <div className="card" style={{ width: '100%', maxWidth: 420, padding: 28 }}>
        <div style={{ textAlign: 'center', marginBottom: 22 }}>
          <div style={{ width: 86, height: 86, borderRadius: 24, background: schoolColor, margin: '0 auto 14px', display: 'grid', placeItems: 'center', overflow: 'hidden', color: '#fff', fontSize: 36 }}>
            {schoolLogo ? <img src={schoolLogo} alt="logo" style={{ width: '100%', height: '100%', objectFit: 'cover' }} /> : '🏫'}
          </div>
          <h1 className="h1">{schoolName}</h1>
          <p className="sub">تسجيل الدخول بكود المدرسة</p>
        </div>

        <Field label="كود الدخول" value={code} onChange={e => { setCode(e.target.value); setError('') }} placeholder="ADM001 / TCH001 / STD001" onKeyDown={e => e.key === 'Enter' && submit()} />
        {error && <div className="card" style={{ background: '#fff1f2', borderColor: '#fecdd3', color: '#e11d48', padding: 12, marginBottom: 14 }}>⚠️ {error}</div>}
        <Button onClick={submit} disabled={loading} style={{ width: '100%', opacity: loading ? .7 : 1 }}>{loading ? 'جاري الدخول...' : 'تسجيل الدخول'}</Button>

        <hr className="sep" />
        <div className="small" style={{ textAlign: 'center', marginBottom: 8, fontWeight: 700 }}>أكواد تجريبية</div>
        <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap', justifyContent: 'center' }}>
          {Object.keys(codes).map(c => <button key={c} className="btn btn-soft" style={{ padding: '8px 10px', fontSize: 11 }} onClick={() => setCode(c)}>{c}</button>)}
        </div>
      </div>
    </div>
  )
}

function AppShell(props) {
  const { user, logout, schoolName, schoolLogo, schoolColor, tab, setTab, unreadCount } = props
  const [mobileMenu, setMobileMenu] = useState(false)

  const tabs = useMemo(() => {
    const admin = [
      ['home', '🏠', 'الرئيسية'],
      ['teachers', '👨‍🏫', 'المعلمون'],
      ['students', '👨‍🎓', 'الطلاب'],
      ['fees', '💰', 'الرسوم'],
      ['settings', '⚙️', 'الإعدادات'],
    ]
    const teacher = [
      ['home', '🏠', 'الرئيسية'],
      ['mystudents', '👨‍🎓', 'طلابي'],
      ['attendance', '📋', 'الحضور'],
      ['ratings', '⭐', 'التقييمات'],
      ['messages', '💬', 'الرسائل', unreadCount(user.id)],
    ]
    const student = [
      ['home', '🏠', 'الرئيسية'],
      ['myreport', '📊', 'تقريري'],
      ['attendance', '📋', 'حضوري'],
      ['fees', '💰', 'رسومي'],
      ['messages', '💬', 'الرسائل', unreadCount(user.id)],
    ]
    return user.role === 'admin' ? admin : user.role === 'teacher' ? teacher : student
  }, [user, unreadCount])

  const renderPage = () => {
    if (tab === 'home') return <HomePage {...props} />
    if (tab === 'teachers' && user.role === 'admin') return <TeachersPage {...props} />
    if (tab === 'students' && user.role === 'admin') return <StudentsPage {...props} />
    if (tab === 'fees' && user.role === 'admin') return <FeesAdminPage {...props} />
    if (tab === 'fees' && user.role === 'student') return <StudentFeesPage {...props} />
    if (tab === 'settings' && user.role === 'admin') return <SettingsPage {...props} />
    if (tab === 'mystudents' && user.role === 'teacher') return <MyStudentsPage {...props} />
    if (tab === 'attendance' && user.role === 'teacher') return <AttendanceTeacherPage {...props} />
    if (tab === 'attendance' && user.role === 'student') return <AttendanceStudentPage {...props} />
    if (tab === 'ratings' && user.role === 'teacher') return <RatingsPage {...props} />
    if (tab === 'myreport' && user.role === 'student') return <MyReportPage {...props} />
    if (tab === 'messages') return <MessagesPage {...props} />
    return <HomePage {...props} />
  }

  return (
    <div className="app-shell">
      <aside className="sidebar">
        <div className="brand">
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <div style={{ width: 40, height: 40, borderRadius: 14, overflow: 'hidden', background: 'rgba(255,255,255,.12)', display: 'grid', placeItems: 'center', flex: '0 0 auto' }}>
              {schoolLogo ? <img src={schoolLogo} alt="logo" style={{ width: '100%', height: '100%', objectFit: 'cover' }} /> : '🏫'}
            </div>
            <div>
              <h1>{schoolName}</h1>
              <p>نظام إدارة مدرسي</p>
            </div>
          </div>
        </div>
        <div className="user">
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <div style={{ width: 36, height: 36, borderRadius: 12, background: 'rgba(255,255,255,.18)', display: 'grid', placeItems: 'center' }}>{user.role === 'admin' ? '👑' : user.role === 'teacher' ? '👨‍🏫' : '👨‍🎓'}</div>
            <div>
              <div style={{ fontWeight: 800, fontSize: 13 }}>{user.name}</div>
              <div className="small" style={{ color: 'rgba(255,255,255,.65)' }}>{user.role === 'admin' ? 'مدير' : user.role === 'teacher' ? 'معلم' : 'طالب'}</div>
            </div>
          </div>
        </div>

        <nav>
          {tabs.map(([id, icon, label, badge]) => (
            <button key={id} className={`navbtn ${tab === id ? 'active' : ''}`} onClick={() => { setTab(id); setMobileMenu(false) }}>
              <span>{icon}</span>
              <span style={{ flex: 1 }}>{label}</span>
              {!!badge && badge > 0 && <span className="badge">{badge}</span>}
            </button>
          ))}
        </nav>

        <div style={{ padding: 12 }}>
          <button className="navbtn" onClick={logout} style={{ justifyContent: 'flex-start' }}>🚪 <span>تسجيل الخروج</span></button>
        </div>
      </aside>

      {mobileMenu && (
        <div className="modal-bg" style={{ zIndex: 40 }} onMouseDown={() => setMobileMenu(false)}>
          <div className="sidebar" style={{ display: 'flex', width: 250, height: '100vh', position: 'relative' }} onMouseDown={e => e.stopPropagation()}>
            <div className="brand">...
            </div>
          </div>
        </div>
      )}

      <main className="content">
        <div className="topbar">
          <button className="btn btn-soft" onClick={() => setMobileMenu(true)}>☰</button>
          <div style={{ fontWeight: 900 }}>{schoolName}</div>
          <div style={{ width: 36, height: 36, borderRadius: 12, background: schoolColor, color: '#fff', display: 'grid', placeItems: 'center', fontWeight: 900 }}>{user.name[0]}</div>
        </div>
        <div className="main">{renderPage()}</div>
      </main>
    </div>
  )
}

function HomePage({ user, teachers, students, messages, attendance, ratings }) {
  if (user.role === 'admin') {
    const total = students.reduce((s, x) => s + (x.fees || 0), 0)
    const paid = students.reduce((s, x) => s + (x.feesPaid || 0), 0)
    const today = attendance.filter(a => a.date === fmtDate())
    return (
      <div>
        <div className="section-head"><div><h1 className="h1">👑 لوحة المدير</h1><p className="sub">مرحبًا، هذا ملخص اليوم</p></div></div>
        <div className="grid grid-4">
          <Stat label="الطلاب" value={students.length} />
          <Stat label="المعلمون" value={teachers.length} />
          <Stat label="تحصيل الرسوم" value={`${total ? Math.round((paid / total) * 100) : 0}%`} />
          <Stat label="حضور اليوم" value={today.filter(a => a.status === 'present').length} />
        </div>
        <div className="card" style={{ marginTop: 14 }}><p className="label">نسبة تحصيل الرسوم</p><Progress value={paid} max={total || 1} /></div>
      </div>
    )
  }

  if (user.role === 'teacher') {
    const mine = students.filter(s => s.teacherId === user.id)
    const today = attendance.filter(a => a.teacherId === user.id && a.date === fmtDate())
    const unread = messages.filter(m => m.toId === user.id && !m.read).length
    return (
      <div>
        <div className="section-head"><div><h1 className="h1">👨‍🏫 لوحة المعلم</h1><p className="sub">{user.name}</p></div></div>
        <div className="grid grid-4">
          <Stat label="طلابي" value={mine.length} />
          <Stat label="حضور اليوم" value={`${today.filter(a => a.status === 'present').length}/${mine.length}`} />
          <Stat label="رسائل جديدة" value={unread} />
          <Stat label="التقييمات" value={ratings.filter(r => r.teacherId === user.id).length} />
        </div>
      </div>
    )
  }

  const me = students.find(s => s.id === user.id) || {}
  const unread = messages.filter(m => m.toId === user.id && !m.read).length
  const lastRate = ratings.filter(r => r.studentId === user.id).sort((a, b) => b.createdAt - a.createdAt)[0]
  const feePct = me.fees ? Math.round((me.feesPaid / me.fees) * 100) : 0
  return (
    <div>
      <div className="section-head"><div><h1 className="h1">👨‍🎓 لوحة الطالب</h1><p className="sub">{me.grade || ''} — {me.level || '—'}</p></div></div>
      <div className="grid grid-4">
        <Stat label="الحضور" value={`${me.attendance || 0}%`} />
        <Stat label="المعدل" value={`${me.gpa || 0}%`} />
        <Stat label="رسائل جديدة" value={unread} />
        <Stat label="الرسوم" value={`${feePct}%`} />
      </div>
      {lastRate && <div className="card" style={{ marginTop: 14 }}><p className="label">آخر تقييم</p><h3 style={{ margin: '0 0 6px' }}>{lastRate.title}</h3><div className="small">{lastRate.note}</div></div>}
    </div>
  )
}

function TeachersPage({ teachers, setTeachers, students, schoolColor }) {
  const [modal, setModal] = useState(false)
  const [edit, setEdit] = useState(null)
  const [del, setDel] = useState(null)
  const [q, setQ] = useState('')
  const filtered = teachers.filter(t => [t.name, t.subject, t.id].some(x => x.toLowerCase().includes(q.toLowerCase())))

  const save = (data) => {
    if (edit) setTeachers(teachers.map(t => t.id === edit.id ? { ...t, ...data } : t))
    else setTeachers([...teachers, { id: `TCH${uid()}`, ...data }])
    setModal(false)
  }
  const remove = () => { setTeachers(teachers.filter(t => t.id !== del)); setDel(null) }

  return (
    <div>
      <div className="section-head">
        <div><h1 className="h1">👨‍🏫 المعلمون</h1><p className="sub">إدارة بيانات المعلمين</p></div>
        <Button onClick={() => { setEdit(null); setModal(true) }}>＋ إضافة معلم</Button>
      </div>
      <input className="input search" placeholder="🔍 بحث..." value={q} onChange={e => setQ(e.target.value)} />
      <div className="list">
        {filtered.map(t => (
          <div key={t.id} className="row">
            <div className="avatar">👨‍🏫</div>
            <div style={{ flex: 1 }}>
              <div style={{ fontWeight: 900 }}>{t.name}</div>
              <div className="meta">{t.subject} · {t.classes} فصول · {students.filter(s => s.teacherId === t.id).length} طالب</div>
              <div className="small">{t.id}</div>
            </div>
            <div style={{ display: 'flex', gap: 8 }}>
              <Button variant="soft" onClick={() => { setEdit(t); setModal(true) }}>تعديل</Button>
              <Button variant="soft" onClick={() => setDel(t.id)}>حذف</Button>
            </div>
          </div>
        ))}
        {!filtered.length && <div className="card" style={{ textAlign: 'center' }}>لا توجد نتائج</div>}
      </div>
      {modal && <TeacherModal item={edit} onClose={() => setModal(false)} onSave={save} />}
      {del && <Confirm title="حذف معلم" onCancel={() => setDel(null)} onConfirm={remove} />}
    </div>
  )
}

function TeacherModal({ item, onClose, onSave }) {
  const [name, setName] = useState(item?.name || '')
  const [subject, setSubject] = useState(item?.subject || '')
  const [classes, setClasses] = useState(item?.classes || 0)
  const [err, setErr] = useState('')
  const submit = () => {
    if (!name.trim() || !subject.trim()) return setErr('الاسم والمادة مطلوبان')
    onSave({ name: name.trim(), subject: subject.trim(), classes: Number(classes) || 0 })
  }
  return (
    <Modal title={item ? 'تعديل معلم' : 'إضافة معلم'} onClose={onClose}>
      <Field label="الاسم" value={name} onChange={e => setName(e.target.value)} placeholder="أ. محمود علي" />
      <Field label="المادة" value={subject} onChange={e => setSubject(e.target.value)} placeholder="رياضيات" />
      <Field label="عدد الفصول" type="number" value={classes} onChange={e => setClasses(e.target.value)} placeholder="4" />
      {err && <div className="card" style={{ background: '#fff1f2', borderColor: '#fecdd3', color: '#e11d48', padding: 12, marginBottom: 14 }}>⚠️ {err}</div>}
      <div style={{ display: 'flex', gap: 10 }}><Button onClick={submit}>حفظ</Button><Button variant="soft" onClick={onClose}>إلغاء</Button></div>
    </Modal>
  )
}

function StudentsPage({ students, setStudents, teachers }) {
  const [modal, setModal] = useState(false)
  const [edit, setEdit] = useState(null)
  const [del, setDel] = useState(null)
  const [q, setQ] = useState('')
  const filtered = students.filter(s => [s.name, s.grade, s.id].some(x => x.toLowerCase().includes(q.toLowerCase())))

  const save = (data) => {
    if (edit) setStudents(students.map(s => s.id === edit.id ? { ...s, ...data } : s))
    else setStudents([...students, { id: `STD${uid()}`, ...data }])
    setModal(false)
  }
  const remove = () => { setStudents(students.filter(s => s.id !== del)); setDel(null) }

  return (
    <div>
      <div className="section-head">
        <div><h1 className="h1">👨‍🎓 الطلاب</h1><p className="sub">إدارة بيانات الطلاب</p></div>
        <Button onClick={() => { setEdit(null); setModal(true) }}>＋ إضافة طالب</Button>
      </div>
      <input className="input search" placeholder="🔍 بحث..." value={q} onChange={e => setQ(e.target.value)} />
      <div className="list">
        {filtered.map(s => {
          const t = teachers.find(x => x.id === s.teacherId)
          return (
            <div key={s.id} className="row">
              <div className="avatar">👨‍🎓</div>
              <div style={{ flex: 1 }}>
                <div style={{ fontWeight: 900 }}>{s.name}</div>
                <div className="meta">{s.grade} · {t?.name || '—'} · المستوى: {s.level || '—'}</div>
                <div className="small">{s.id}</div>
              </div>
              <div style={{ minWidth: 90, textAlign: 'center' }}><div className="small">المعدل</div><strong>{s.gpa}%</strong></div>
              <div style={{ minWidth: 110, textAlign: 'center' }}><div className="small">الرسوم</div><strong>{s.feesPaid}/{s.fees}</strong></div>
              <div style={{ display: 'flex', gap: 8 }}>
                <Button variant="soft" onClick={() => { setEdit(s); setModal(true) }}>تعديل</Button>
                <Button variant="soft" onClick={() => setDel(s.id)}>حذف</Button>
              </div>
            </div>
          )
        })}
        {!filtered.length && <div className="card" style={{ textAlign: 'center' }}>لا توجد نتائج</div>}
      </div>
      {modal && <StudentModal item={edit} teachers={teachers} onClose={() => setModal(false)} onSave={save} />}
      {del && <Confirm title="حذف طالب" onCancel={() => setDel(null)} onConfirm={remove} />}
    </div>
  )
}

function StudentModal({ item, teachers, onClose, onSave }) {
  const [name, setName] = useState(item?.name || '')
  const [grade, setGrade] = useState(item?.grade || '')
  const [attendance, setAttendance] = useState(item?.attendance ?? 100)
  const [gpa, setGpa] = useState(item?.gpa ?? 0)
  const [teacherId, setTeacherId] = useState(item?.teacherId || '')
  const [fees, setFees] = useState(item?.fees ?? 0)
  const [feesPaid, setFeesPaid] = useState(item?.feesPaid ?? 0)
  const [level, setLevel] = useState(item?.level || 'جيد')
  const [err, setErr] = useState('')

  const submit = () => {
    if (!name.trim() || !grade.trim()) return setErr('الاسم والصف مطلوبان')
    onSave({
      name: name.trim(), grade: grade.trim(), attendance: Number(attendance) || 0, gpa: Number(gpa) || 0,
      teacherId, fees: Number(fees) || 0, feesPaid: Number(feesPaid) || 0, level,
    })
  }

  return (
    <Modal title={item ? 'تعديل طالب' : 'إضافة طالب'} onClose={onClose}>
      <div className="grid grid-2">
        <Field label="الاسم" value={name} onChange={e => setName(e.target.value)} placeholder="محمد أحمد" />
        <Field label="الصف" value={grade} onChange={e => setGrade(e.target.value)} placeholder="الصف الأول" />
        <Field label="الحضور %" type="number" value={attendance} onChange={e => setAttendance(e.target.value)} placeholder="95" />
        <Field label="المعدل %" type="number" value={gpa} onChange={e => setGpa(e.target.value)} placeholder="89" />
        <Field label="إجمالي الرسوم" type="number" value={fees} onChange={e => setFees(e.target.value)} placeholder="5000" />
        <Field label="المدفوع" type="number" value={feesPaid} onChange={e => setFeesPaid(e.target.value)} placeholder="3000" />
      </div>
      <div className="grid grid-2">
        <SelectField label="المعلم المسؤول" value={teacherId} onChange={e => setTeacherId(e.target.value)}>
          <option value="">— اختر معلماً —</option>
          {teachers.map(t => <option key={t.id} value={t.id}>{t.name}</option>)}
        </SelectField>
        <SelectField label="المستوى" value={level} onChange={e => setLevel(e.target.value)}>
          {['ممتاز', 'جيد جداً', 'جيد', 'مقبول', 'ضعيف'].map(l => <option key={l} value={l}>{l}</option>)}
        </SelectField>
      </div>
      {err && <div className="card" style={{ background: '#fff1f2', borderColor: '#fecdd3', color: '#e11d48', padding: 12, marginBottom: 14 }}>⚠️ {err}</div>}
      <div style={{ display: 'flex', gap: 10 }}><Button onClick={submit}>حفظ</Button><Button variant="soft" onClick={onClose}>إلغاء</Button></div>
    </Modal>
  )
}

function MyStudentsPage({ user, students }) {
  const mine = students.filter(s => s.teacherId === user.id)
  return (
    <div>
      <div className="section-head"><div><h1 className="h1">👨‍🎓 طلابي</h1><p className="sub">{mine.length} طالب</p></div></div>
      <div className="list">{mine.map(s => <div key={s.id} className="row"><div className="avatar">👨‍🎓</div><div style={{ flex: 1 }}><div style={{ fontWeight: 900 }}>{s.name}</div><div className="meta">{s.grade}</div><div className="small">{s.id}</div></div><Badge color="#dcfce7" text="#15803d">{s.level || '—'}</Badge><strong>{s.gpa}%</strong></div>)}{!mine.length && <div className="card" style={{ textAlign: 'center' }}>لا يوجد طلاب مخصصون لك</div>}</div>
    </div>
  )
}

function AttendanceTeacherPage({ user, students, attendance, setAttendance }) {
  const mine = students.filter(s => s.teacherId === user.id)
  const today = fmtDate()
  const todayRecords = attendance.filter(a => a.teacherId === user.id && a.date === today)
  const statusOf = sid => todayRecords.find(a => a.studentId === sid)?.status || ''

  const mark = (studentId, status) => {
    const rest = attendance.filter(a => !(a.teacherId === user.id && a.date === today && a.studentId === studentId))
    setAttendance([...rest, { teacherId: user.id, studentId, date: today, status, time: fmtTime() }])
  }

  const history = [...new Set(attendance.filter(a => a.teacherId === user.id).map(a => a.date))].sort().reverse().slice(0, 7)

  return (
    <div>
      <div className="section-head"><div><h1 className="h1">📋 الحضور</h1><p className="sub">تسجيل حضور اليوم</p></div></div>
      <div className="card" style={{ marginBottom: 14 }}>
        <div className="list">
          {mine.map(s => (
            <div key={s.id} className="row" style={{ boxShadow: 'none' }}>
              <div style={{ flex: 1 }}>
                <div style={{ fontWeight: 900 }}>{s.name}</div>
                <div className="meta">{s.grade}</div>
              </div>
              <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
                {[['present', 'حاضر'], ['late', 'متأخر'], ['absent', 'غائب']].map(([k, label]) => (
                  <button key={k} className="btn" style={{ background: statusOf(s.id) === k ? (k === 'present' ? '#16a34a' : k === 'late' ? '#f59e0b' : '#ef4444') : '#e2e8f0', color: statusOf(s.id) === k ? '#fff' : '#334155', padding: '8px 12px' }} onClick={() => mark(s.id, k)}>{label}</button>
                ))}
              </div>
            </div>
          ))}
          {!mine.length && <div className="small" style={{ textAlign: 'center', padding: 20 }}>لا يوجد طلاب</div>}
        </div>
      </div>
      <div className="card">
        <p className="label">الأيام السابقة</p>
        <div className="list">
          {history.map(d => {
            const day = attendance.filter(a => a.teacherId === user.id && a.date === d)
            return <div key={d} className="row"><strong>{d}</strong><div style={{ marginInlineStart: 'auto', display: 'flex', gap: 8, flexWrap: 'wrap' }}><Badge color="#dcfce7" text="#15803d">حاضر {day.filter(a => a.status === 'present').length}</Badge><Badge color="#fee2e2" text="#b91c1c">غائب {day.filter(a => a.status === 'absent').length}</Badge></div></div>
          })}
          {!history.length && <div className="small" style={{ textAlign: 'center', padding: 10 }}>لا يوجد سجل بعد</div>}
        </div>
      </div>
    </div>
  )
}

function AttendanceStudentPage({ user, attendance }) {
  const mine = attendance.filter(a => a.studentId === user.id).sort((a, b) => b.date.localeCompare(a.date))
  const p = mine.filter(a => a.status === 'present').length
  const l = mine.filter(a => a.status === 'late').length
  const a = mine.filter(a => a.status === 'absent').length
  const percent = mine.length ? Math.round((p / mine.length) * 100) : 0
  return (
    <div>
      <div className="section-head"><div><h1 className="h1">📋 حضوري</h1><p className="sub">سجل حضورك</p></div></div>
      <div className="grid grid-3" style={{ marginBottom: 14 }}>
        <Stat label="حاضر" value={p} />
        <Stat label="متأخر" value={l} />
        <Stat label="غائب" value={a} />
      </div>
      <div className="card" style={{ marginBottom: 14 }}><p className="label">نسبة الحضور</p><Progress value={p} max={mine.length || 1} /><div style={{ marginTop: 10 }}><Badge color="#e0f2fe" text="#0369a1">{percent}%</Badge></div></div>
      <div className="card"><p className="label">السجل التفصيلي</p><div className="list">{mine.map((x, i) => <div key={i} className="row"><strong>{x.date}</strong><span className="small">{x.time}</span><span style={{ marginInlineStart: 'auto' }}><Badge color={x.status === 'present' ? '#dcfce7' : x.status === 'late' ? '#fef3c7' : '#fee2e2'} text={x.status === 'present' ? '#15803d' : x.status === 'late' ? '#b45309' : '#b91c1c'}>{x.status === 'present' ? 'حاضر' : x.status === 'late' ? 'متأخر' : 'غائب'}</Badge></span></div>)}{!mine.length && <div className="small" style={{ textAlign: 'center', padding: 10 }}>لا يوجد سجل بعد</div>}</div></div>
    </div>
  )
}

function RatingsPage({ user, students, ratings, setRatings }) {
  const mine = students.filter(s => s.teacherId === user.id)
  const [studentId, setStudentId] = useState(mine[0]?.id || '')
  const [stars, setStars] = useState(5)
  const [title, setTitle] = useState('')
  const [note, setNote] = useState('')

  useEffect(() => {
    if (!studentId && mine[0]?.id) setStudentId(mine[0].id)
  }, [mine, studentId])

  const save = () => {
    if (!studentId || !title.trim()) return
    setRatings([...ratings, { id: uid(), teacherId: user.id, studentId, stars, title: title.trim(), note: note.trim(), createdAt: Date.now(), date: fmtDate() }])
    setTitle(''); setNote(''); setStars(5)
  }
  const remove = id => setRatings(ratings.filter(r => r.id !== id))
  const myRatings = ratings.filter(r => r.teacherId === user.id).sort((a, b) => b.createdAt - a.createdAt)

  return (
    <div>
      <div className="section-head"><div><h1 className="h1">⭐ التقييمات</h1><p className="sub">إرسال تقارير للطلاب</p></div></div>
      <div className="card" style={{ marginBottom: 14 }}>
        <SelectField label="الطالب" value={studentId} onChange={e => setStudentId(e.target.value)}>
          <option value="">— اختر —</option>
          {mine.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
        </SelectField>
        <div style={{ marginBottom: 14 }}>
          <label className="label">النجوم</label>
          <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
            {[1, 2, 3, 4, 5].map(n => <button key={n} className="btn btn-soft" onClick={() => setStars(n)} style={{ fontSize: 18, padding: '8px 12px', background: n <= stars ? '#fff7ed' : '#f1f5f9' }}>{n <= stars ? '⭐' : '☆'}</button>)}
          </div>
        </div>
        <Field label="العنوان" value={title} onChange={e => setTitle(e.target.value)} placeholder="أداء ممتاز في الاختبار" />
        <TextareaField label="الملاحظات" value={note} onChange={e => setNote(e.target.value)} placeholder="اكتب التقرير هنا..." rows={4} />
        <Button onClick={save}>إرسال التقييم</Button>
      </div>
      <div className="card"><p className="label">التقييمات السابقة</p><div className="list">{myRatings.map(r => (<div key={r.id} className="row"><div style={{ flex: 1 }}><div style={{ fontWeight: 900 }}>{students.find(s => s.id === r.studentId)?.name || r.studentId}</div><div className="meta">{r.title}</div><div className="small">{r.date} · {'⭐'.repeat(r.stars)}</div>{r.note && <div className="small" style={{ marginTop: 6 }}>{r.note}</div>}</div><Button variant="soft" onClick={() => remove(r.id)}>حذف</Button></div>))}{!myRatings.length && <div className="small" style={{ textAlign: 'center', padding: 10 }}>لا توجد تقييمات</div>}</div></div>
    </div>
  )
}

function MyReportPage({ user, students, teachers, ratings }) {
  const me = students.find(s => s.id === user.id) || {}
  const teacher = teachers.find(t => t.id === me.teacherId)
  const myRatings = ratings.filter(r => r.studentId === user.id).sort((a, b) => b.createdAt - a.createdAt)
  return (
    <div>
      <div className="section-head"><div><h1 className="h1">📊 تقريري</h1><p className="sub">ملخصك الأكاديمي</p></div></div>
      <div className="grid grid-2" style={{ marginBottom: 14 }}>
        <div className="card"><p className="label">المعدل</p><h3 style={{ margin: 0, fontSize: 28 }}>{me.gpa || 0}%</h3></div>
        <div className="card"><p className="label">الحضور</p><h3 style={{ margin: 0, fontSize: 28 }}>{me.attendance || 0}%</h3></div>
        <div className="card"><p className="label">المعلم المسؤول</p><h3 style={{ margin: 0, fontSize: 22 }}>{teacher?.name || '—'}</h3></div>
        <div className="card"><p className="label">المستوى</p><Badge color="#e0f2fe" text="#0369a1">{me.level || '—'}</Badge></div>
      </div>
      <div className="card"><p className="label">التقييمات</p><div className="list">{myRatings.map(r => <div key={r.id} className="row"><div style={{ flex: 1 }}><div style={{ fontWeight: 900 }}>{r.title}</div><div className="small">{r.date} · {'⭐'.repeat(r.stars)}</div>{r.note && <div className="small" style={{ marginTop: 6 }}>{r.note}</div>}</div></div>)}{!myRatings.length && <div className="small" style={{ textAlign: 'center', padding: 10 }}>لا توجد تقييمات</div>}</div></div>
    </div>
  )
}

function MessagesPage({ user, students, teachers, messages, setMessages }) {
  const [conv, setConv] = useState('')
  const [text, setText] = useState('')
  const endRef = useRef(null)

  const contacts = useMemo(() => {
    if (user.role === 'teacher') return students.filter(s => s.teacherId === user.id).map(s => ({ id: s.id, name: s.name, role: 'student' }))
    if (user.role === 'student') {
      const me = students.find(s => s.id === user.id)
      const t = teachers.find(x => x.id === me?.teacherId)
      return t ? [{ id: t.id, name: t.name, role: 'teacher' }] : []
    }
    return []
  }, [user, students, teachers])

  useEffect(() => {
    if (!conv) return
    const updated = messages.map(m => m.fromId === conv && m.toId === user.id && !m.read ? { ...m, read: true } : m)
    if (JSON.stringify(updated) !== JSON.stringify(messages)) setMessages(updated)
  }, [conv])

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [conv, messages.length])

  const thread = conv ? messages.filter(m => (m.fromId === user.id && m.toId === conv) || (m.fromId === conv && m.toId === user.id)).sort((a, b) => a.ts - b.ts) : []
  const send = () => {
    if (!conv || !text.trim()) return
    setMessages([...messages, { id: uid(), fromId: user.id, toId: conv, text: text.trim(), ts: Date.now(), time: fmtTime(), read: false }])
    setText('')
  }
  const lastMessage = id => messages.filter(m => (m.fromId === id && m.toId === user.id) || (m.fromId === user.id && m.toId === id)).sort((a, b) => b.ts - a.ts)[0]?.text || 'لا توجد رسائل'
  const unread = id => messages.filter(m => m.fromId === id && m.toId === user.id && !m.read).length

  return (
    <div>
      <div className="section-head"><div><h1 className="h1">💬 الرسائل</h1><p className="sub">محادثات داخلية</p></div></div>
      <div className="chat-wrap">
        <div className="panel">
          <div className="panel-head">المحادثات</div>
          <div className="panel-body" style={{ padding: 0 }}>
            {!contacts.length && <div className="small" style={{ textAlign: 'center', padding: 20 }}>لا توجد محادثات</div>}
            {contacts.map(c => (
              <button key={c.id} className={`contact ${conv === c.id ? 'active' : ''}`} onClick={() => setConv(c.id)}>
                <div className="avatar" style={{ width: 38, height: 38 }}>{c.role === 'teacher' ? '👨‍🏫' : '👨‍🎓'}</div>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', gap: 8 }}>
                    <strong style={{ fontSize: 12 }}>{c.name}</strong>
                    {unread(c.id) > 0 && <Badge color="#fee2e2" text="#b91c1c">{unread(c.id)}</Badge>}
                  </div>
                  <div className="small" style={{ overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{lastMessage(c.id)}</div>
                </div>
              </button>
            ))}
          </div>
        </div>

        <div className="panel">
          <div className="panel-head">{contacts.find(c => c.id === conv)?.name || 'اختر محادثة'}</div>
          <div className="panel-body" style={{ background: '#f8fafc', display: 'flex', flexDirection: 'column' }}>
            {!conv ? (
              <div className="small" style={{ margin: 'auto', textAlign: 'center' }}>ابدأ محادثة من القائمة</div>
            ) : (
              <>
                <div style={{ flex: 1 }}>
                  {thread.map(m => (
                    <div key={m.id} style={{ display: 'flex', justifyContent: m.fromId === user.id ? 'flex-start' : 'flex-end' }}>
                      <div className={`bubble ${m.fromId === user.id ? 'me' : 'other'}`}>
                        <div style={{ fontSize: 13, lineHeight: 1.7 }}>{m.text}</div>
                        <div className="small" style={{ textAlign: m.fromId === user.id ? 'left' : 'right', opacity: .7, color: m.fromId === user.id ? '#cbd5e1' : '#64748b' }}>{m.time}</div>
                      </div>
                    </div>
                  ))}
                  <div ref={endRef} />
                </div>
                <div style={{ display: 'flex', gap: 10, marginTop: 10 }}>
                  <input className="input" value={text} onChange={e => setText(e.target.value)} onKeyDown={e => e.key === 'Enter' && send()} placeholder="اكتب رسالتك..." />
                  <Button onClick={send}>إرسال</Button>
                </div>
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}

function FeesAdminPage({ students, setStudents }) {
  const [edit, setEdit] = useState(null)
  const total = students.reduce((s, x) => s + (x.fees || 0), 0)
  const paid = students.reduce((s, x) => s + (x.feesPaid || 0), 0)
  const update = (id, feesPaid) => {
    setStudents(students.map(s => s.id === id ? { ...s, feesPaid: Number(feesPaid) || 0 } : s))
    setEdit(null)
  }

  return (
    <div>
      <div className="section-head"><div><h1 className="h1">💰 الرسوم</h1><p className="sub">إدارة رسوم الطلاب</p></div></div>
      <div className="grid grid-3" style={{ marginBottom: 14 }}>
        <Stat label="إجمالي الرسوم" value={total.toLocaleString()} />
        <Stat label="المحصّل" value={paid.toLocaleString()} />
        <Stat label="المتبقي" value={(total - paid).toLocaleString()} />
      </div>
      <div className="card" style={{ marginBottom: 14 }}><p className="label">نسبة التحصيل</p><Progress value={paid} max={total || 1} /></div>
      <div className="card">
        <p className="label">تفاصيل الطلاب</p>
        <div className="list">
          {students.map(s => {
            const pct = s.fees ? Math.round((s.feesPaid / s.fees) * 100) : 0
            return (
              <div key={s.id} className="row">
                <div style={{ flex: 1 }}>
                  <div style={{ fontWeight: 900 }}>{s.name}</div>
                  <div className="meta">{s.grade}</div>
                </div>
                <Badge color={pct >= 100 ? '#dcfce7' : '#fef3c7'} text={pct >= 100 ? '#15803d' : '#b45309'}>{pct >= 100 ? 'مكتمل' : `${pct}%`}</Badge>
                <Button variant="soft" onClick={() => setEdit(s)}>تحديث</Button>
              </div>
            )
          })}
        </div>
      </div>
      {edit && <FeeModal student={edit} onClose={() => setEdit(null)} onSave={update} />}
    </div>
  )
}

function FeeModal({ student, onClose, onSave }) {
  const [paid, setPaid] = useState(student.feesPaid || 0)
  return (
    <Modal title={`تحديث رسوم ${student.name}`} onClose={onClose}>
      <div className="card" style={{ marginBottom: 14 }}><div className="small">إجمالي الرسوم: <strong>{student.fees?.toLocaleString() || 0}</strong></div></div>
      <Field label="المدفوع" type="number" value={paid} onChange={e => setPaid(e.target.value)} placeholder="3000" />
      <div style={{ display: 'flex', gap: 10 }}><Button onClick={() => onSave(student.id, paid)}>حفظ</Button><Button variant="soft" onClick={onClose}>إلغاء</Button></div>
    </Modal>
  )
}

function StudentFeesPage({ user, students }) {
  const me = students.find(s => s.id === user.id) || {}
  const pct = me.fees ? Math.round((me.feesPaid / me.fees) * 100) : 0
  return (
    <div>
      <div className="section-head"><div><h1 className="h1">💰 رسومي</h1><p className="sub">حالة السداد</p></div></div>
      <div className="grid grid-3" style={{ marginBottom: 14 }}>
        <Stat label="إجمالي الرسوم" value={(me.fees || 0).toLocaleString()} />
        <Stat label="المدفوع" value={(me.feesPaid || 0).toLocaleString()} />
        <Stat label="المتبقي" value={Math.max(0, (me.fees || 0) - (me.feesPaid || 0)).toLocaleString()} />
      </div>
      <div className="card"><p className="label">نسبة السداد</p><Progress value={me.feesPaid || 0} max={me.fees || 1} /><div style={{ marginTop: 12 }}>{pct >= 100 ? <Badge color="#dcfce7" text="#15803d">تم السداد بالكامل</Badge> : <Badge color="#fff7ed" text="#c2410c">يوجد مبلغ متبقٍ</Badge>}</div></div>
    </div>
  )
}

function SettingsPage({ schoolName, schoolColor, schoolLogo, setSchoolName, setSchoolColor, setSchoolLogo }) {
  const [name, setName] = useState(schoolName)
  const [color, setColor] = useState(schoolColor)
  const [saved, setSaved] = useState(false)
  const fileRef = useRef(null)
  const colors = ['#173a5e', '#0f766e', '#7c3aed', '#be185d', '#1d4ed8', '#065f46', '#b45309']

  const upload = e => {
    const file = e.target.files?.[0]
    if (!file) return
    const reader = new FileReader()
    reader.onload = ev => setSchoolLogo(ev.target.result)
    reader.readAsDataURL(file)
  }

  const save = () => {
    setSchoolName(name.trim() || schoolName)
    setSchoolColor(color)
    setSaved(true)
    setTimeout(() => setSaved(false), 1500)
  }

  return (
    <div>
      <div className="section-head"><div><h1 className="h1">⚙️ الإعدادات</h1><p className="sub">تخصيص الاسم واللون والشعار</p></div></div>
      <div className="grid grid-2">
        <div className="card">
          <Field label="اسم المدرسة" value={name} onChange={e => setName(e.target.value)} placeholder="اسم المدرسة" />
          <div className="label">اللون الرئيسي</div>
          <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', marginBottom: 12 }}>
            {colors.map(c => <button key={c} onClick={() => setColor(c)} style={{ width: 36, height: 36, borderRadius: 12, background: c, border: color === c ? '3px solid #fff' : '3px solid transparent', boxShadow: color === c ? `0 0 0 2px ${c}` : 'none', cursor: 'pointer' }} />)}
          </div>
          <input type="color" className="input" style={{ padding: 6, height: 48 }} value={color} onChange={e => setColor(e.target.value)} />
        </div>
        <div className="card" style={{ textAlign: 'center' }}>
          <div style={{ width: 84, height: 84, borderRadius: 24, background: color, margin: '0 auto 14px', display: 'grid', placeItems: 'center', overflow: 'hidden', color: '#fff', fontSize: 36 }}>
            {schoolLogo ? <img src={schoolLogo} alt="logo" style={{ width: '100%', height: '100%', objectFit: 'cover' }} /> : '🏫'}
          </div>
          <div style={{ display: 'flex', gap: 10, justifyContent: 'center', flexWrap: 'wrap' }}>
            <Button onClick={() => fileRef.current?.click()}>رفع صورة</Button>
            {schoolLogo && <Button variant="soft" onClick={() => setSchoolLogo(null)}>إزالة الشعار</Button>}
          </div>
          <input ref={fileRef} type="file" accept="image/*" hidden onChange={upload} />
        </div>
      </div>
      <div style={{ marginTop: 14 }}><Button onClick={save} style={{ background: saved ? '#16a34a' : color, width: '100%' }}>{saved ? 'تم الحفظ' : 'حفظ الإعدادات'}</Button></div>
    </div>
  )
}

function Confirm({ title, onConfirm, onCancel }) {
  return (
    <div className="modal-bg" onMouseDown={onCancel}>
      <div className="modal" style={{ maxWidth: 380 }} onMouseDown={e => e.stopPropagation()}>
        <h2 className="h1" style={{ fontSize: 20, marginBottom: 8 }}>{title}</h2>
        <p className="sub" style={{ marginBottom: 20 }}>هل أنت متأكد؟ لا يمكن التراجع.</p>
        <div style={{ display: 'flex', gap: 10 }}><Button onClick={onConfirm}>نعم، احذف</Button><Button variant="soft" onClick={onCancel}>إلغاء</Button></div>
      </div>
    </div>
  )
}

export default App
